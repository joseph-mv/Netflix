import { api_key } from "./Constants";

export const originals=`discover/tv?api_key=${api_key}&with_networks=213`
export const actions=`discover/movie?api_key=${api_key}&with_genres=28`
export const comedy=`discover/movie?api_key=${api_key}&with_genres=35`
