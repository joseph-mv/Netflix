export const baseUrl='https://api.themoviedb.org/3/'
export const api_key='8fc7da3fef50f249d7baddd84e0f9290'
export const imageUrl='https://image.tmdb.org/t/p/original/'

